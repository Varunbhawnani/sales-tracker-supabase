/**
 * tally-bridge.js — Supabase Edition
 *
 * Listens to public.queries for rows with status = 'pending_verification',
 * verifies each invoice against Tally's Day Book, and updates the row.
 *
 * Differences from the Firebase version:
 *   - Uses @supabase/supabase-js with the SERVICE_ROLE key (bypasses RLS).
 *   - Subscribes via Supabase Realtime instead of Firestore onSnapshot.
 *   - All other logic identical, including the §25 auth-failure handling.
 */

require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const TALLY_URL = process.env.TALLY_URL || 'http://localhost:9003';
const TALLY_USER = process.env.TALLY_USER || '';
const TALLY_PASS = process.env.TALLY_PASS || '';
const TALLY_COMPANY = process.env.TALLY_COMPANY || '';

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error('❌ SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY must be set in .env. Exiting.');
  process.exit(1);
}
if (!TALLY_USER || !TALLY_PASS) {
  console.warn('⚠️  TALLY_USER / TALLY_PASS not set in .env — Tally will likely reject the request.');
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: { autoRefreshToken: false, persistSession: false },
});

// 5-minute cooldown after auth failure (same as Firebase version)
const AUTH_FAILURE_COOLDOWN_MS = 5 * 60 * 1000;

console.log('🚀 Tally Bridge (Supabase) running, listening for pending verifications…');

// Helper: process a single pending-verification row
async function processVerification(row) {
  const invoiceNo = row.tally_invoice_number;
  if (!invoiceNo) return;

  // Auth-failure cooldown
  if (row.last_auth_failure_at) {
    const sinceFailMs = Date.now() - new Date(row.last_auth_failure_at).getTime();
    if (sinceFailMs < AUTH_FAILURE_COOLDOWN_MS) {
      console.log(`⏸  Auth-failure cooldown active for ${invoiceNo}, skipping.`);
      return;
    }
  }

  console.log(`\n🔍 Checking Tally for Invoice: ${invoiceNo}`);

  const today = new Date();
  const pastDate = new Date();
  pastDate.setDate(today.getDate() - 3);
  const fmt = (d) =>
    d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');

  const xmlPayload = `<ENVELOPE>
    <HEADER><TALLYREQUEST>Export Data</TALLYREQUEST></HEADER>
    <BODY><EXPORTDATA><REQUESTDESC>
      <REPORTNAME>Day Book</REPORTNAME>
      <STATICVARIABLES>
        <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
        ${TALLY_COMPANY ? `<SVCURRENTCOMPANY>${TALLY_COMPANY}</SVCURRENTCOMPANY>` : ''}
        ${TALLY_USER ? `<SVUSERNAME>${TALLY_USER}</SVUSERNAME>` : ''}
        ${TALLY_PASS ? `<SVPASSWORD>${TALLY_PASS}</SVPASSWORD>` : ''}
        <SVFROMDATE>${fmt(pastDate)}</SVFROMDATE>
        <SVTODATE>${fmt(today)}</SVTODATE>
        <SVVOUCHERTYPE>BOX SALES (FACTORIES)</SVVOUCHERTYPE>
      </STATICVARIABLES>
    </REQUESTDESC></EXPORTDATA></BODY>
  </ENVELOPE>`;

  let response;
  try {
    response = await axios.post(TALLY_URL, xmlPayload, {
      headers: { 'Content-Type': 'application/xml' }, timeout: 30000,
    });
  } catch (err) {
    console.error(`❌ Tally connection error for ${invoiceNo}:`, err.message);
    return; // Leave row untouched — Layer-3 timeout warning will surface in the app
  }

  const tallyData = response.data;
  const searchTag = `<VOUCHERNUMBER>${invoiceNo}</VOUCHERNUMBER>`;

  if (tallyData.includes(searchTag)) {
    console.log(`✅ MATCH FOUND! Invoice ${invoiceNo} exists in Tally.`);
    await supabase.from('queries').update({
      status: 'verified_pending_dispatch',
      verification_timestamp: new Date().toISOString(),
      verification_error: null,
      last_activity_at: new Date().toISOString(),
    }).eq('id', row.id);
  } else if (tallyData.includes('Authentication Failed')) {
    console.error(`🔐 Tally auth failed for ${invoiceNo}. Bumping retry counter.`);
    await supabase.from('queries').update({
      verification_error: 'Tally authentication failed — escalate to admin',
      auth_failure_count: (row.auth_failure_count || 0) + 1,
      last_auth_failure_at: new Date().toISOString(),
      // status intentionally stays as pending_verification
    }).eq('id', row.id);
  } else {
    console.log(`❌ Invoice ${invoiceNo} NOT found in Tally within the last 3 days.`);
    await supabase.from('queries').update({
      status: 'verification_failed',
      verification_error: `Invoice "${invoiceNo}" not found in Tally (checked last 3 days)`,
      verification_timestamp: new Date().toISOString(),
      last_activity_at: new Date().toISOString(),
    }).eq('id', row.id);
  }
}

// Initial sweep: process any queries that are already pending_verification.
async function initialSweep() {
  const { data, error } = await supabase
    .from('queries').select('*').eq('status', 'pending_verification');
  if (error) {
    console.error('Initial sweep failed:', error);
    return;
  }
  console.log(`Initial sweep: ${(data || []).length} pending-verification queries.`);
  for (const row of data || []) {
    await processVerification(row);
  }
}

// Realtime subscription for new pending_verification rows
function subscribe() {
  return supabase
    .channel('public:queries:pending')
    .on('postgres_changes', {
      event: '*', schema: 'public', table: 'queries',
      filter: 'status=eq.pending_verification',
    }, async (payload) => {
      const row = payload.new;
      if (!row) return;
      await processVerification(row);
    })
    .subscribe();
}

(async () => {
  await initialSweep();
  subscribe();
  console.log('🎧 Listening for pending verifications…');
})();
